See LINUX_INSTALL.md — same package for Mint and Ubuntu (0.3.0).

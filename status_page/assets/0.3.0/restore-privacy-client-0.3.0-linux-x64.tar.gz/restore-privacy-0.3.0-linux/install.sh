#!/usr/bin/env bash
# Restore Privacy Linux installer — uses BUNDLED wheels only (no network pip).
# Remaining system packages (python3, venv, tk, ip): installed via apt if missing.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
VENV="$ROOT/.venv"
WHEELS="$ROOT/wheels"
REQ="$ROOT/requirements.txt"

echo "=== Restore Privacy Linux installer (deps baked in) ==="
echo "Package root: $ROOT"

if ! command -v python3 >/dev/null 2>&1; then
  echo "ERROR: python3 is required (Ubuntu 20.04+). sudo apt-get install -y python3"
  exit 1
fi

PY_OK="$(python3 -c 'import sys; print(1 if sys.version_info >= (3, 8) else 0)')"
if [[ "$PY_OK" != "1" ]]; then
  echo "ERROR: Need Python 3.8+ (Ubuntu 20.04 LTS or newer)."
  exit 1
fi

# System floor only — app deps come from wheels/
need_apt=0
command -v ip >/dev/null 2>&1 || need_apt=1
python3 -c "import venv" 2>/dev/null || need_apt=1
python3 -c "import tkinter" 2>/dev/null || need_apt=1
if [[ "$need_apt" -eq 1 ]]; then
  if command -v apt-get >/dev/null 2>&1; then
    echo "Installing system packages: python3-venv python3-tk iproute2..."
    sudo apt-get update -y
    sudo DEBIAN_FRONTEND=noninteractive apt-get install -y \
      python3-venv python3-tk iproute2 || true
  fi
fi

if ! python3 -c "import venv" 2>/dev/null; then
  echo "ERROR: python3-venv missing. sudo apt-get install -y python3-venv"
  exit 1
fi
if ! python3 -c "import tkinter" 2>/dev/null; then
  echo "ERROR: python3-tk missing (GUI). sudo apt-get install -y python3-tk"
  exit 1
fi
if ! command -v ip >/dev/null 2>&1; then
  echo "ERROR: ip (iproute2) missing. sudo apt-get install -y iproute2"
  exit 1
fi

if [[ ! -d "$WHEELS" ]] || ! ls "$WHEELS"/*.whl >/dev/null 2>&1; then
  echo "ERROR: bundled wheels/ missing — corrupt package. Re-download the release tar.gz."
  exit 1
fi

echo "Creating private virtualenv at $VENV (offline install from wheels/)..."
rm -rf "$VENV"
python3 -m venv "$VENV"
# shellcheck disable=SC1091
source "$VENV/bin/activate"
python -m pip install --upgrade pip --no-index --find-links="$WHEELS" 2>/dev/null || true
# Offline only — never hits PyPI
if [[ -f "$REQ" ]]; then
  python -m pip install --no-index --find-links="$WHEELS" -r "$REQ"
else
  python -m pip install --no-index --find-links="$WHEELS" cryptography cffi pycparser
fi

# Verify cryptography from venv (not system)
python -c "import cryptography; print('cryptography', cryptography.__version__, 'OK (bundled)')"

# Secrets
SECRETS_DIR="${HOME}/.restore-privacy/secrets"
mkdir -p "$SECRETS_DIR"
if [[ -f "$ROOT/secrets/node_elgamal.pub" ]]; then
  cp -f "$ROOT/secrets/node_elgamal.pub" "$SECRETS_DIR/"
  echo "Installed node public key to $SECRETS_DIR"
fi

# Ensure launcher is executable
chmod +x "$ROOT/bin/privacy-restored" 2>/dev/null || true
chmod +x "$ROOT/install.sh" 2>/dev/null || true

# Desktop entry → bundled launcher
APPS="${HOME}/.local/share/applications"
mkdir -p "$APPS"
cat > "$APPS/privacy-restored.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Privacy Restored
Comment=Restore Privacy VPN (Linux installer package)
Exec=pkexec env DISPLAY=\$DISPLAY XAUTHORITY=\$XAUTHORITY $ROOT/bin/privacy-restored
Path=$ROOT
Terminal=false
Categories=Network;Security;
EOF
echo "Desktop entry: $APPS/privacy-restored.desktop"

if [[ ! -e /dev/net/tun ]]; then
  echo "Loading tun module..."
  sudo modprobe tun || true
fi

echo ""
echo "Install complete. App Python deps are in $VENV (from bundled wheels)."
echo "  Run GUI (root for full tunnel):"
echo "    sudo $ROOT/bin/privacy-restored"
echo "  Or: $ROOT/bin/privacy-restored   # will request elevation on Connect"

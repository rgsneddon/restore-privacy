#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
PREFIX="${RPOS_PREFIX:-$HOME/.rpos/install}"
# Real user Desktop by default (immediate discovery); also stage under prefix/Desktop
if [[ -n "${RPOS_DESKTOP:-}" ]]; then
  DESKTOP="$RPOS_DESKTOP"
elif [[ -n "${XDG_DESKTOP_DIR:-}" ]]; then
  DESKTOP="$XDG_DESKTOP_DIR"
elif [[ -d "$HOME/Desktop" ]]; then
  DESKTOP="$HOME/Desktop"
else
  DESKTOP="$HOME/Desktop"
fi
PREFIX_DESKTOP="$PREFIX/Desktop"
mkdir -p "$PREFIX/apps" "$DESKTOP" "$PREFIX_DESKTOP"
cp -a "$ROOT/apps/." "$PREFIX/apps/"
export PYTHONPATH="$PREFIX/apps${PYTHONPATH:+:$PYTHONPATH}"
_write_launcher() {
  local dest="$1"
  cat > "$dest" <<LAUNCH
#!/usr/bin/env bash
export PYTHONPATH="$PREFIX/apps${PYTHONPATH:+:$PYTHONPATH}"
exec python3 -m rpoffice.apps.tables "$@"
LAUNCH
  chmod +x "$dest"
}
_write_launcher "$DESKTOP/Tables"
_write_launcher "$PREFIX_DESKTOP/Tables"
echo "[install] Tables → $DESKTOP/Tables (and $PREFIX_DESKTOP/)"
python3 -m rpoffice.apps.tables --version || true

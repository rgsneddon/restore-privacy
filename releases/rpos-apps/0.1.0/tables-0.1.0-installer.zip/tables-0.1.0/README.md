# Tables — Restore Privacy

Free with **rpOS**. Standalone installer package.

```bash
bash install.sh
# places Tables on Desktop and under install prefix
```

# Pens — Restore Privacy

Free with **rpOS**. Standalone installer package.

```bash
bash install.sh
# places Pens on Desktop and under install prefix
```

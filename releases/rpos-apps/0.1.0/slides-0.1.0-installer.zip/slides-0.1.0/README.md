# Slides — Restore Privacy

Free with **rpOS**. Standalone installer package.

```bash
bash install.sh
# places Slides on Desktop and under install prefix
```

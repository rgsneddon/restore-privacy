$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Prefix = if ($env:RPOS_PREFIX) { $env:RPOS_PREFIX } else { Join-Path $env:USERPROFILE ".rpos\install" }
# Real user Desktop by default
if ($env:RPOS_DESKTOP) { $Desktop = $env:RPOS_DESKTOP }
elseif (Test-Path (Join-Path $env:USERPROFILE "Desktop")) { $Desktop = Join-Path $env:USERPROFILE "Desktop" }
else { $Desktop = Join-Path $env:USERPROFILE "Desktop" }
$PrefixDesktop = Join-Path $Prefix "Desktop"
New-Item -ItemType Directory -Force -Path (Join-Path $Prefix "apps") | Out-Null
New-Item -ItemType Directory -Force -Path $Desktop | Out-Null
New-Item -ItemType Directory -Force -Path $PrefixDesktop | Out-Null
Copy-Item -Recurse -Force (Join-Path $Root "apps\*") (Join-Path $Prefix "apps")
$Body = @"
@echo off
set PYTHONPATH=$Prefix\apps;%PYTHONPATH%
python -m rpoffice.apps.slides %*
"@
$Body | Set-Content -Path (Join-Path $Desktop "Slides.cmd") -Encoding ASCII
$Body | Set-Content -Path (Join-Path $PrefixDesktop "Slides.cmd") -Encoding ASCII
Write-Host "[install] Slides → $Desktop\Slides.cmd"

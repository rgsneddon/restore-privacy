See LINUX_INSTALL.md for the bake-in installer package (0.5.5).

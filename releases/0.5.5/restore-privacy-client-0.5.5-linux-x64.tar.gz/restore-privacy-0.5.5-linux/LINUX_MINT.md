See LINUX_INSTALL.md — same package for Mint and Ubuntu (0.5.5).
